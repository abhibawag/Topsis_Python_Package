This is a command line tool to calculate Topsis Score and Rank 
https://github.com/abhibawag/Topsis_Python_Package
Author : Abhhishek Bawa
github: https://github.com/abhibawag/
E-mail: abhibawa357@gmail.com